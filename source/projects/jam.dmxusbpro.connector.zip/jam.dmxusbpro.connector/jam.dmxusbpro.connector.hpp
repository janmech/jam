    /// Definition of the jam.ilda.manager data structures.
    /// Unlike the convention this is not done in the c file, because other object files need acces to this as well
#include "c74_min_api.h"
#include <mutex>



#ifndef jam_dmxusbpro_connector_h
#define jam_dmxusbpro_connector_h

typedef struct _jam_dupc
{
    std::mutex _file_access_lock;
    c74::max::t_object s_obj;     // t_object header
    
} t_jam_dupc;
#endif //jam_dmxusbpro_connector_h


