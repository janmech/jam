/// This is global max objext that shall be loaded as an extension by placing it inside the extension folder of the package
/// this is a frankenstein-ish patching a traditional c-style max object into the project, because it seems that it is not possible to create nobox object with min-defkit

#include "jam.dmxusbpro.connector.hpp"

using namespace c74::max;

C74_EXPORT


    // function prototypes
void *jam_dupc_new(t_symbol *s, long argc, t_atom *argv);

t_jam_dupc *  jam_dupc_get_struct(t_jam_dupc *x);



static t_class *s_jam_dupc_class; // global pointer to our class definition that is setup in ext_main()


void ext_main(void *r)
{
    t_class *c;
    c = class_new("jam.dmxusbpro.connector", (method)jam_dupc_new, (method)NULL, sizeof(t_jam_dupc), 0L, 0);
    class_addmethod(c, (method)jam_dupc_get_struct, "get_struct", 0);
    s_jam_dupc_class = c;
    class_register(CLASS_NOBOX, c);
}

void *jam_dupc_new(t_symbol *s, long argc, t_atom *argv)
{
    static t_jam_dupc *x = NULL;
    if(x == NULL) {
        x = (t_jam_dupc *)object_alloc(s_jam_dupc_class);
    }
    return x;
}

t_jam_dupc *  jam_dupc_get_struct(t_jam_dupc *x) {
    return x;
};


